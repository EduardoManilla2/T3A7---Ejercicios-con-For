package ejercicio.pkg3;

import java.util.Scanner;

public class Ejercicio3 {

    public static void main(String[] args) {
        empleado();
    }

    public static void empleado() {
        Scanner scanner = new Scanner(System.in);
        nombre nombres = new nombre();
        double sumaSalarios = 0;
        

        int empleados = 0;
        System.out.println("Ingrese la cantidad de empleados a registrar: ");
        empleados = scanner.nextInt();

        for (int i = 1; i <= empleados; i++) {
            System.out.println("Ingrese los datos del empleado: ");

            System.out.print("Nombre: ");
            String nombre = scanner.next();
            nombres.setNombre(nombre);
            

            System.out.print("Salario: ");
            int setSalario = scanner.nextInt();
            nombres.setSalario(setSalario);
            System.out.println("\n");

            if (setSalario >= 0){
                sumaSalarios = sumaSalarios + setSalario;
                
             
           
            }else{
                System.out.println("Ese numero no es uno del los numeros impares ");
                break;
            }
            System.out.println("El total de la suma de los salarios es: " + sumaSalarios);
                
            
      }
        double promedioSalario = sumaSalarios/empleados;
        System.out.println("El promedio de los salarios es: " + promedioSalario);
    }
  }

