package ejercicio.pkg3;

public class nombre {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private int Salario = 0;
    private double promedio = 0;
    
    public nombre() {}

    public nombre(String nombre, String apellidoPaterno, String apellidoMaterno, int salario, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.Salario = salario;
        this.promedio = promedio;
    }

    
    
      @Override
    public String toString() {
        return "Calificaciones{" + "nombre=" + nombre + 
                "Salario=" + Salario + 
                ", promedio=" + getPromedio() + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public int getSalario() {
        return Salario;
    }

    public void setSalario(int salario) {
        this.Salario = salario;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
}
            
            
    

