package ejercicio.pkg4;

import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) {
        ejercicio4();
    }
    //Dadas las edades y alturas de 5 alumnos, mostrar la edad y la estatura media, 
    //la cantidad de alumnos mayores de 18 a�os, y la cantidad de alumnos 
    //      que miden m�s de 1.75.

    public static void ejercicio4() {
        Scanner scanner = new Scanner(System.in);
        int edad;
        int mayorDe18 = 0;
        int mayorDe175 = 0;
        float estatura , sumaEstatura=0;
        double promedioEstatura = 0;

        for (int i = 0; i < 5; i++) {

            System.out.print("Edad: ");
            edad = scanner.nextInt();
            if(edad > 18){
                mayorDe18++;
            }

            System.out.println("Estatura: ");
            estatura = scanner.nextFloat();
            
            if (estatura > 1.75){
                mayorDe175++;
            }
            
           sumaEstatura = sumaEstatura + estatura;
            promedioEstatura = sumaEstatura / 5;
            

            
        }
        
        System.out.println("Mayor de 18 a�os: " + mayorDe18);
        System.out.println("Mayor de 1.75: "+ mayorDe175);
        System.out.println("Promedio de estatura: " + promedioEstatura);

    }

}
