package ejercicio.pkg1;

import java.util.Scanner;

public class Ejercicio1 {

    
    public static void main(String[] args) {
       ejercicio1();
    }
    
    public static void ejercicio1(){
    Scanner scanner = new Scanner(System.in);
        System.out.println("+------------------------------------------------+");
        System.out.println("Cuantos numeros quieres sumar: ");
        int limite = scanner.nextInt();
        
        System.out.println("Desde que numero deseas iniciar: ");
        int inicio = scanner.nextInt();
        
        System.out.println("Incremento: ");
        int incremento = scanner.nextInt();
        System.out.println("+------------------------------------------------+");
        
        int numsuma = inicio + limite;
        System.out.println("\nInicio: " + inicio
        + "\nLimite: " + numsuma
        + "\nCantidad de n�meros a sumar: " + limite);
        System.out.println("+------------------------------------------------+\n");
        
        
        int suma = 0;
        for (int numero = inicio; numero <= numsuma; numero += incremento){
        
            System.out.println("Suma de los numeros: " + numero);
            
            
            
        }
        
        
        }
                
        
    }
    

