package ejercicio.pkg2;

import java.util.Scanner;

public class Ejercicio2 {

    //1,3,5,7,9,11,13,15,17,19
    public static void main(String[] args) {
     numeros();
    }
    

    public static void numeros() {
        Scanner scanner = new Scanner(System.in);
        double numero = 0;
        double suma = 1 ;
        for (int i = 0; i <= 9; i = i + 1) {

            System.out.println("Ingrese el numero impar: ");
            numero = scanner.nextDouble();
            
            if (numero == 1 || numero == 3 ||
                    numero == 5 || numero == 7 ||
                    numero == 9 || numero == 11 ||
                    numero == 13 || numero == 15 ||
                    numero == 17 || numero == 19){
                suma = suma*numero;
             
           
            }else{
                System.out.println("Ese numero no es uno del los numeros impares ");
                break;
            }
        }
            System.out.println("El total de la suma de los numeros impares es: " + suma);
            
    }

}
